# This script is to estimate relationships between non-natal rearing (freq by rearing type and prop of FW growth)
# vs upper Sac flow and juvenile abundance (density dependence)

# Clear workspace
rm(list=ls())

#Load packages
if (!require("pacman")) install.packages("pacman")
library(pacman)
p_load(ggplot2, dplyr, tidyverse, rsq)

#-------------------------------

# define years of interest (brood years with OK sample sizes)
yrs = c(2004, 2005, 2006, 2012, 2013, 2014)

# Read in mean Sac flows for Aug-Jan of each BY
flow_8.1 = read.csv("outputs/mean_aug_jan_flows.csv")

# Read in rearing categories
rearing_type_summary = read.csv('outputs/rearing_type_by_BY.csv') %>%
  filter(rearing_type == "SAC") %>%
  mutate(prop_non_nat_rearers = 1-freq) %>%
  select(-rearing_type, -n)

# Create combined data table for regression analyses
annual_df = left_join(flow_8.1, 
                      rearing_type_summary[c("Brood_year", "tot", "prop_non_nat_rearers")], 
                      by = c("BY" = "Brood_year"))

# Read in mean annual fw growth
mean_fw_growth = read.csv('outputs/summary_stats_fw_growth.csv')

# estimate total fraction of FW growth assimilated in any non natal habitat
tot_non_nat_rearing = mean_fw_growth %>%
  filter(Brood_year %in% yrs, !Habitat %in% c("SAC")) %>%
  group_by(Brood_year) %>%
  summarize(tot_non_natal = sum(mean_prop_fw_growth))

# estimate total fraction of FW growth assimilated in a downstream non natal habitat
down_rearing = mean_fw_growth %>%
  filter(Brood_year %in% yrs, !Habitat %in% c("SAC", "Unassigned", "LAS")) %>%
  group_by(Brood_year) %>%
  summarize(prop_fw_growth_down = sum(mean_prop_fw_growth))

#add to combined df
annual_df = left_join(annual_df, tot_non_nat_rearing, by = c("BY" = "Brood_year"))
annual_df = left_join(annual_df, down_rearing, by = c("BY" = "Brood_year"))

# read in total juvenile production per year from FWS (JPI estimate)
juv_production = read.csv('data/RBDD_RST_Juv_Production.csv')

#add to combined df
annual_df = left_join(annual_df, juv_production)

##------------------------------------------------------------------------------------------

# PROPORTION OF FISH EACH YEAR ASSIGNED TO A REARING TYPE OTHER THAN SAC (i.e. REARED NON-NATALLY)
# AS A FUNCTION OF MEAN AUG-APR FLOW

non_nat = ggplot(annual_df, aes(x = av_flow8.1, y = prop_non_nat_rearers, label = BY))+
  geom_smooth(method = "glm", aes(weight = tot), fill="grey", colour="black", size=2, alpha = 0.3) +
  geom_point(aes(size = tot),  shape = 16, alpha = 0.9) + 
  geom_text_repel(aes(label=BY),hjust=0.4, vjust=0.7) +
  theme_classic(base_size = 18) +
  scale_y_continuous(breaks=seq(0,1.1,0.25)) +
  labs(x = "Mean flow Aug-Jan (cms)", y = "Proportion of individuals \n that reared non-natally",
       size = "No. adults \nanalyzed")+
  theme(legend.position = "none"); non_nat


# add r2 value to plot
lm <- lm(prop_non_nat_rearers ~ av_flow8.1, weight = tot, data = annual_df)
summary(lm)
plot(resid(lm))

r2 = format(rsq(lm,adj=TRUE), digits = 2)
non_nat2 = non_nat + geom_text(x = 170, y = .74, label = paste("r^2 == ",r2), parse = TRUE, color = "black"); non_nat2

##----------------- PROPORTION OF FW GROWTH IN NON NATAL HABITATS ('Rest stop hypothesis') -------------

rest = ggplot(annual_df, aes(x = av_flow8.1, y = tot_non_natal, label = BY))+
  geom_smooth(method = "glm", aes(weight = tot), fill="grey", colour="black", size=2, alpha = 0.3) +
  geom_point(aes(size = tot), shape = 16, fill = "black", alpha = 0.9) + 
  geom_text_repel(aes(label=BY),hjust=0.2, vjust=0.2)  +
  theme_classic(base_size = 18) +
  labs(x = "Mean flow Aug-Jan (cms)", y = "Mean fraction of growth\nin non-natal habitats",
       size = "No. adults \nanalyzed"); rest

# add r2 value to plot
lm <- lm(tot_non_natal ~ av_flow8.1, weights = tot, data = annual_df)
summary(lm)
plot(resid(lm))

r2 = format(rsq(lm,adj=TRUE), digits = 2)
rest2 = rest + geom_text(x = 176, y = 0.56, label = paste("r^2 == ",r2), parse = TRUE, color = "black"); rest2

#COMBINING BOTH PLOTS INTO ONE
fig6 = cowplot::plot_grid(non_nat2, rest2, ncol=2, labels = c("A", "B"),
                          rel_widths = c(1,1.4)); fig6

ggsave(file="figures/Fig6_rest_stop.jpg", 
       fig6, width = 25, height = 12, dpi = 320, units = "cm")


##------------------- DOWWNSTREAM OCCUPANCY --------------------------------------
# downstream nonnatal habitats (FEA/DEL, AME) used more when cues come earlier
# Based on del Rosario et al (2013) (“mainstem Sacramento River flow threshold of 400 m3 s-1 triggers abrupt and substantial winter-run migration into the Delta at Knights Landing”) we hypothesize that there will be a negative relationship between the date of the first freshet and the proportion of freshwater growth in downstream non-natal habitats (below Knights Landing, i.e. DEL/FEA & AME combined). 

cues = ggplot(annual_df, aes(x = broodyr_day, y = prop_fw_growth_down, label = BY, color =  av_flow8.1)) + 
  geom_smooth(method = "glm", fill="grey", colour="black", size=2, alpha = 0.3,
              aes(weight = tot)) +
  geom_point(aes(size = tot), shape = 16, fill = "black", alpha = 0.65) + 
  geom_text_repel(aes(label=BY),hjust=0.2, vjust=0.2)  +
  theme_classic(base_size = 18) +
  labs(x = "First day >400cms", 
       y = "Mean fraction of growth\nin downstream habitats",
       size = "No. adults \nanalyzed")+ 
  theme(legend.position = "none") +ylim(0.05,0.53)+ 
  scale_color_gradient(low = "orangered3", high = "slateblue4"); cues

# add r2 value to plot
lm <- lm(prop_fw_growth_down ~ broodyr_day, weights = tot, data = annual_df)
summary(lm)
plot(resid(lm))
r2 = format(rsq(lm,adj=TRUE), digits = 2)
cues2 = cues + geom_text(x = 166, y = 0.52, label = paste("r^2 == ",r2), color = "black", parse = TRUE); cues2


##---------------------------------------------------------
# DENSITY DEPENDENT MOVEMENT 
# Hypothesis = In years of increased juvenile production there will be increased downstream 
# movement of juveniles (as upstream habitats become saturated; Greene & Beechie, 2004; Hendrix et al., 2017) resulting in a positive relationship between juvenile abundance and the proportion of rearing in downstream habitats (American River and Feather River/Delta). 

juv = ggplot(annual_df, aes(x = Fry_equiv_JPI/1000000, y = prop_fw_growth_down,                   
                            label = BY, color =  av_flow8.1)) + 
  geom_smooth(method = "glm", fill="grey", colour="black", size=2, alpha = 0.3,
              aes(weight = tot)) +
  geom_point(aes(size = tot), shape = 16, fill = "black", alpha = 0.65) + 
  labs(x = "Juvenile production (millions)", 
       y = "Mean fraction of growth\nin downstream habitats",
       size = "No. adults \nanalyzed",
       color = "Mean Aug-Jan \nflow (cms)") +
  geom_text_repel(aes(label=BY),hjust=0.2, vjust=0.2)  +
  theme_classic(base_size = 18) +
  xlim(0.5,9.5)+ylim(0.05,0.6)+
  scale_color_gradient(low = "orangered3", high = "slateblue4"); juv

# add r2 value to plot
lm <- lm(prop_fw_growth_down ~ Fry_equiv_JPI, weights = tot, data = annual_df)
summary(lm)
plot(resid(lm))
r2 = format(rsq(lm,adj=TRUE), digits = 2)
juv2 = juv + geom_text(x = 1.7, y = 0.58, label = paste("r^2 == ",r2), color = "black", parse = TRUE); juv2

#COMBINE INTO SINGLE FIG
fig8 = cowplot::plot_grid(cues2, juv2, ncol=2, labels = c("A", "B"),
                          rel_widths = c(1, 1.52)); fig8

ggsave(file="figures/Fig8_downstream_occupancy", 
       fig8, width = 28, height = 12, dpi = 320, units = "cm")

##-----------------------------------------------

#Linear model for downstream occupancy prediction combining both terms in one
annual_df$JPI_mill = annual_df$Fry_equiv_JPI/1000000
lm <- lm(prop_fw_growth_down ~ JPI_mill +broodyr_day, weights = tot, data = annual_df)
summary(lm)